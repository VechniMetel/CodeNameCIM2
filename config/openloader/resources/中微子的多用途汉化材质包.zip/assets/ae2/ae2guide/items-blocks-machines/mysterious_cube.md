---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 神秘方块
  icon: mysterious_cube
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:mysterious_cube
- ae2:not_so_mysterious_cube
---

# 神秘方块

<BlockImage id="mysterious_cube" scale="8" />

还记得需要寻找多个陨石才能集齐所有压印模板的日子吗？现在陨石内部会生成神秘方块。

尝试破坏它（不使用精准采集）会发生什么有趣的事呢？

你也可以制作复制品——没那么神秘的方块

## 合成配方

<RecipeFor id="not_so_mysterious_cube" />