---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 无线接收器
  icon: wireless_receiver
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:wireless_receiver
---

# 无线接收器

<ItemImage id="wireless_receiver" scale="4" />

安装在反射盘中的<ItemLink id="fluix_pearl" />（福鲁伊克斯珍珠），是短程ME无线技术的核心组件。

## 合成配方

<RecipeFor id="wireless_receiver" />