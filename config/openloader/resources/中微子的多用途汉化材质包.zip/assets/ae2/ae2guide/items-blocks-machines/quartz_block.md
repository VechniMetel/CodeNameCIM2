---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 赛特斯石英块
  icon: quartz_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_block
---

# 赛特斯石英块

<BlockImage id="quartz_block" scale="8" />

这是<ItemLink id="certus_quartz_crystal" />（赛特斯石英水晶）的存储方块，可用于制作[萌芽赛特斯石英母岩](budding_certus.md)或[装饰性赛特斯石英块](decorative_certus.md)。

## 合成配方

<RecipeFor id="quartz_block" />