---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 赛特斯石英水晶
  icon: certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_crystal
---

# 赛特斯石英水晶

<ItemImage id="certus_quartz_crystal" scale="4" />

*"赛特斯石英水晶具备独特性质，其晶格结构可承载大量能量"*

AE2设备、方块及物品的核心原料之一。通过[赛特斯石英母岩](../ae2-mechanics/certus-growth.md)培育获取。

## 替代配方

<Recipe id="misc/deconstruction_certus_quartz_block" />

<Recipe id="transform/certus_quartz_crystals" />