---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 物质球
  icon: matter_ball
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:matter_ball
---

# 物质球

<ItemImage id="matter_ball" scale="4" />

一种通用物质聚合体，可用作<ItemLink id="matter_cannon" />（物质炮）的弹药或用于生产[染色球](paintballs.md)。

在<ItemLink id="condenser" />（物质聚合器）的物质球模式下，消耗256个物品或流体桶可制成。