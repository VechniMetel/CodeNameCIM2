---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 陨石储罐
  icon: sky_stone_tank
  position: 310
categories:
- machines
item_ids:
- ae2:sky_stone_tank
---

# 陨石储罐

<BlockImage id="sky_stone_tank" scale="8" />

这是一个可存储16桶流体的储罐装置。被破坏时不会保留内部存储的流体，没有其他特殊功能。

## 合成配方

<RecipeFor id="sky_stone_tank" />