---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 迷你TNT
  icon: tiny_tnt
  position: 010
categories:
- 杂项/材料/方块
item_ids:
- ae2:tiny_tnt
---

# 迷你TNT

<BlockImage id="tiny_tnt" scale="8" />

小型TNT，适用于小范围爆破。用于制作成对的<ItemLink id="quantum_entangled_singularity" />（量子缠绕态奇点）。

可通过配置文件禁用其方块破坏效果，适用于想在服务器中禁用TNT和苦力怕破坏的场景。

## 合成配方

<RecipeFor id="tiny_tnt" />