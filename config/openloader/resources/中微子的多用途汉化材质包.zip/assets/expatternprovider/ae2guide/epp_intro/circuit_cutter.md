---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 电路切片器
    icon: expatternprovider:circuit_cutter
categories:
- 扩展设备
item_ids:
- expatternprovider:circuit_cutter
---

# 电路切片器

<Row gap="20">
<BlockImage id="expatternprovider:circuit_cutter" scale="8"></BlockImage>
</Row>

无法忍受压印器的缓慢速度？现在有了电路切片器！它们能够将材料块直接切割成处理器印版，在多数情况下比压印器快9倍速度。

**注意：没有端口的玻璃面无法连接至网络。**