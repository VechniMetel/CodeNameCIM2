---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 扩展压印器
    icon: expatternprovider:ex_inscriber
categories:
- extended devices
item_ids:
- expatternprovider:ex_inscriber
---

# 扩展压印器

<Row gap="20">
<BlockImage id="expatternprovider:ex_inscriber" scale="8"></BlockImage>
</Row>

扩展压印器是<ItemLink id="ae2:inscriber" />的进阶版本。

可同时执行4项压印作业。

配备与原版相同的堆叠调节按钮，可设置物品栏的最大堆叠数量。

建议搭配<ItemLink id="ae2:pattern_provider" />使用时将堆叠数量设为1，以避免潜在问题。