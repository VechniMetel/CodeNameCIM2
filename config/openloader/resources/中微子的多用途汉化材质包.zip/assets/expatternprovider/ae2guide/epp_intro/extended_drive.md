---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME扩展驱动器
    icon: expatternprovider:ex_drive
categories:
- extended devices
item_ids:
- expatternprovider:ex_drive
---

# ME扩展驱动器

<Row gap="20">
<BlockImage id="expatternprovider:ex_drive" scale="8"></BlockImage>
</Row>

ME扩展驱动器是<ItemLink id="ae2:drive" />的升级版本，具有扩容的存储单元舱室。可同时容纳20个存储元件。