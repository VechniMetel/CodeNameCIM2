本资源包是适用于 Minecraft 1.20.1 Forge 的简体中文资源包，提供模组的简体中文本地化。

作者为逐日炎雪中微子，基于CFPA团队的i18nGithub仓库、MC百科的网友友情提供与deepseek v3/r1的帮助制作

i18n的GitHub 仓库：https://github.com/CFPAOrg/Minecraft-Mod-Language-Package

I18n Update Mod 下载方式有
MC百科：https://www.mcmod.cn/download/1188.html
CurseForge：https://www.curseforge.com/minecraft/mc-mods/i18nupdatemod
Modrinth：https://modrinth.com/mod/i18nupdatemod