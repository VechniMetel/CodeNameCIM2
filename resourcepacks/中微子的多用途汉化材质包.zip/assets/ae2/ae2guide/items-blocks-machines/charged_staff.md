---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 充能手杖
  icon: charged_staff
  position: 410
categories:
- tools
item_ids:
- ae2:charged_staff
---

# 充能手杖

<ItemImage id="charged_staff" scale="4" />

由<ItemLink id="charged_certus_quartz_crystal" />与木棍组成的能量武器。每次攻击造成6点伤害，消耗300 AE能量。

可通过<ItemLink id="charger" />补充能量。

## 合成配方

<RecipeFor id="charged_staff" />